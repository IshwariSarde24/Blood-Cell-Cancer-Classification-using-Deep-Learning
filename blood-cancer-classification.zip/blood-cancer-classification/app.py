import os
import numpy as np
from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

app = Flask(__name__)

# Load model
model = load_model("vgg19_finetuned_blood_cancer_model.keras")

# Class labels
classes = [
    "Benign",
    "Malignant Early Pre-B",
    "Malignant Pre-B",
    "Malignant Pro-B"
]

def preprocess(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/upload')
def upload():
    return render_template("upload.html")

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return "No file uploaded"

    file = request.files['file']
    filepath = os.path.join("static", file.filename)
    file.save(filepath)

    img = preprocess(filepath)
    prediction = model.predict(img)
    class_index = np.argmax(prediction)
    result = classes[class_index]
    confidence = round(float(np.max(prediction)) * 100, 2)

    return render_template("upload.html", 
                           prediction=result, 
                           confidence=confidence,
                           image_path=filepath)

if __name__ == "__main__":
    app.run(debug=True)